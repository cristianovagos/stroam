create view SubscribersChannelsPaths_View as
  select
    `s`.`Id`   AS `SubscriberId`,
    `c`.`Id`   AS `ChannelId`,
    `c`.`Path` AS `Path`
  from ((`nottheservicedb`.`Channels` `c`
    join `nottheservicedb`.`Subscribers_Channels` `s_c` on ((`c`.`Id` = `s_c`.`ChannelId`))) join
    `nottheservicedb`.`Subscribers` `s` on ((`s_c`.`SubscriberId` = `s`.`Id`)));

