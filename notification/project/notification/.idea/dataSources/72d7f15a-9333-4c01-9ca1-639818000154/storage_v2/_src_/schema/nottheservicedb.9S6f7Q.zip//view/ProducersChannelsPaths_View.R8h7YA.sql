create view ProducersChannelsPaths_View as
  select
    `p`.`Id`                 AS `ProducerId`,
    `c`.`Id`                 AS `ChannelId`,
    `c`.`Path`               AS `Path`,
    `p_c`.`IsProducerPrefix` AS `IsProducerPrefix`
  from ((`nottheservicedb`.`Channels` `c`
    join `nottheservicedb`.`Producers_Channels` `p_c` on ((`c`.`Id` = `p_c`.`ChannelId`))) join
    `nottheservicedb`.`Producers` `p` on ((`p_c`.`ProducerId` = `p`.`Id`)));

